FOUR RESTAURANTS. ONE PORTABLE HAUNTING.

COMPLETE WEBSITE COLLECTION
Source: Current drafts
Exported: 2026-10-17T16:51:14.908Z

OPEN AND EXPLORE
1. Extract the entire ZIP to one folder.
2. Open index.html to start at Bone Appétit.
3. Use CHOOSE YOUR HAUNT at the top or footer to switch between all four edited restaurants. Each keeps its own design, menu, artwork, story and planner.

PAGES
Bone Appétit: index.html
Rest in Pizza: rest-in-pizza.html
Grave Expectations Chop House: grave-expectations.html
BooBies Lodge: boobies-lodge.html

SHARE
Send the whole ZIP so the recipient can extract it and open index.html. Or serve the entire folder from any static web host, including a subfolder. Keep all four HTML files, scripts, stylesheets and assets together. No internet connection is required to open the extracted sites. JavaScript enables the menus, dialogs and planner; full static menus and details remain readable without it. This download does not publish or send anything.

PLANS
Each property has a separate content-derived browser storage key. Original creator/visitor saves and other edited content are not overwritten. Identical public content uses the same key as its individual website export. Browser storage for file URLs varies; if saving is unavailable, use Download itinerary or Download field notes. A stable static web address provides consistent browser-local resumption. The ZIP contains no visitor plans.

CONTENTS AND EDITING
The four restaurant HTML files contain the full public pages and embedded validated planner data. Shared scripts, original styles, local artwork, four fonts and their licenses are included once. content/ contains a public content snapshot for each property. manifest.json records the source type, public names, routes, separate planner keys, file sizes and SHA-256 checksums. These checksums detect accidental changes; they are not a signature or approval.

Campaign names, working briefs, other campaigns, creator pages and saved plans are excluded. This package is not a creator backup. Keep a separate creator backup for future editing, then export another collection when ready.

FICTION
All four restaurants retain their Halloween parody, fictional prices/facilities and fixed 2026 concept season. The lodge's 21+ admission rule remains in place. No booking, order, payment, subscription or email is submitted.
